﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using Telerik.Sitefinity;
using Telerik.Sitefinity.Modules.Libraries;
using Telerik.Sitefinity.Modules.Pages;
using Telerik.Sitefinity.Taxonomies;
using Telerik.Sitefinity.Web.UI;

namespace SitefinityWebApp.Custom.CustomDesignerExample
{
    /// <summary>
    /// Class used to create custom page widget
    /// </summary>
    /// <remarks>
    /// If this widget is a part of a Sitefinity module,
    /// you can register it in the site's toolbox by adding this to the module's Install/Upgrade method(s):
    /// initializer.Installer
    ///     .Toolbox(CommonToolbox.PageWidgets)
    ///         .LoadOrAddSection(SectionName)
    ///             .SetTitle(SectionTitle) // When creating a new section
    ///             .SetDescription(SectionDescription) // When creating a new section
    ///             .LoadOrAddWidget<CustomWidget>("CustomWidget")
    ///                 .SetTitle("CustomWidget")
    ///                 .SetDescription("CustomWidget")
    ///                 .LocalizeUsing<ModuleResourceClass>() //Optional
    ///                 .SetCssClass(WidgetCssClass) // You can use a css class to add an icon (Optional)
    ///             .Done()
    ///         .Done()
    ///     .Done();
    /// </remarks>
    /// <see cref="http://www.sitefinity.com/documentation/documentationarticles/user-guide/widgets"/>
    [Telerik.Sitefinity.Web.UI.ControlDesign.ControlDesigner(typeof(SitefinityWebApp.Custom.CustomDesignerExample.CustomWidgetDesigner))]
    public class CustomWidget : SimpleView
    {
        #region Properties

        /// <summary>
        /// taxonomy manager
        /// </summary>
        protected TaxonomyManager taxMgr = TaxonomyManager.GetManager();
        /// <summary>
        /// guid from designer for our selected page
        /// </summary>
        public Guid SelectedPageID { get; set; }
        /// <summary>
        /// guid from designer for our selected image
        /// </summary>
        public Guid SelectedImageID { get; set; }
        /// <summary>
        /// source url for our image
        /// </summary>
        public string SelectedImagePath { get; set; }


        /// <summary>
        /// guid array from designer for our selected tags
        /// </summary>
        public Guid[] selectedTags;
       
        // <summary>
        /// Gets or sets the selected tags.
        /// </summary>
        /// <value>
        /// The selected tags.
        /// </value>
        public Guid[] SelectedTags
        {
            get
            {
                if (selectedTags == null) selectedTags = new Guid[] { };
                return selectedTags;
            }
            set { selectedTags = value; }
        }

        /// <summary>
        /// guid array from designer for our selected categories
        /// </summary>
        public Guid[] selectedCategories;
        
        /// <summary>
        /// Gets or sets the selected categories.
        /// </summary>
        /// <value>
        /// The selected categories.
        /// </value>
        public Guid[] SelectedCategories
        {
            get
            {
                if (selectedCategories == null) selectedCategories = new Guid[] { };
                return selectedCategories;
            }
            set { selectedCategories = value; }
        }

        /// <summary>
        /// Obsolete. Use LayoutTemplatePath instead.
        /// </summary>
        protected override string LayoutTemplateName
        {
            get
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Gets the layout template's relative or virtual path.
        /// </summary>
        public override string LayoutTemplatePath
        {
            get
            {
                if (string.IsNullOrEmpty(base.LayoutTemplatePath))
                    return CustomWidget.layoutTemplatePath;
                return base.LayoutTemplatePath;
            }
            set
            {
                base.LayoutTemplatePath = value;
            }
        }

        /// <summary>
        /// Intermediary property for passing Tags to and from the designer
        /// </summary>
        /// <value>
        /// The tag value as a comma delimited string.
        /// </value>
        public string TagValue
        {
            get { return string.Join(",", SelectedTags); }
            set
            {
                var list = new List<Guid>();
                if (value != null)
                {
                    var guids = value.Split(',');
                    foreach (var guid in guids)
                    {
                        Guid newGuid;
                        if (Guid.TryParse(guid, out newGuid))
                            list.Add(newGuid);
                    }
                }
                SelectedTags = list.ToArray();
            }
        }

        /// <summary>
        /// Intermediary property for passing categories to and from the designer
        /// </summary>
        /// <value>
        /// The category value as a comma-delimited string.
        /// </value>
        public string CategoryValue
        {
            get { return string.Join(",", SelectedCategories); }
            set
            {
                var list = new List<Guid>();
                if (value != null)
                {
                    var guids = value.Split(',');
                    foreach (var guid in guids)
                    {
                        Guid newGuid;
                        if (Guid.TryParse(guid, out newGuid))
                            list.Add(newGuid);
                    }
                }
                SelectedCategories = list.ToArray();
            }
        }

        #endregion

        #region Control References

        /// <summary>
        /// Reference to the HyperLink control that shows the page url.
        /// </summary>
        protected virtual HyperLink PageLink
        {
            get
            {
                return this.Container.GetControl<HyperLink>("PageLink", true);
            }
        }

        /// <summary>
        /// Reference to the Image control that shows the image thumbnail.
        /// </summary>
        protected virtual Image Thumbnail
        {
            get
            {
                return this.Container.GetControl<Image>("Thumbnail", true);
            }
        }

        /// <summary>
        /// Reference to the Label control that shows the Message.
        /// </summary>
        protected virtual Repeater TagsRepeater
        {
            get
            {
                return this.Container.GetControl<Repeater>("TagsRepeater", true);
            }
        }

        /// <summary>
        /// Reference to the Label control that shows the Message.
        /// </summary>
        protected virtual Repeater CategoriesRepeater
        {
            get
            {
                return this.Container.GetControl<Repeater>("CategoriesRepeater", true);
            }
        }

        #endregion

        #region Methods
        /// <summary>
        /// Initializes the controls.
        /// </summary>
        /// <param name="container"></param>
        /// <remarks>
        /// Initialize your controls in this method. Do not override CreateChildControls method.
        /// </remarks>
        protected override void InitializeControls(GenericContainer container)
        {
            GetPageLinkInfo();
            GetImageThumbnail();
            BindTags();
            BindCategories();
        }

        /// <summary>
        /// Sets the url and title for your page link control
        /// </summary>
        public void GetPageLinkInfo()
        {
            var mgr = PageManager.GetManager();
            var pageNode = mgr.GetPageNode(SelectedPageID);
            PageLink.NavigateUrl = ResolveUrl(pageNode.GetFullUrl());
            PageLink.Text = pageNode.Title;
            PageLink.Target = "_blank";
        }

        /// <summary>
        /// Sets the selected image's thumbnail to your thumbnail control
        /// </summary>
        private void GetImageThumbnail()
        {
            LibrariesManager libraryManager = LibrariesManager.GetManager();
            var selectedImage = libraryManager.GetImage(SelectedImageID);
            Thumbnail.ImageUrl = selectedImage.ThumbnailUrl;
            Thumbnail.AlternateText = selectedImage.AlternativeText;
        }

        /// <summary>
        /// Binds the selected tags to your tags control
        /// </summary>
        private void BindTags()
        {
            // retrieve selected tags
            var tags = new List<string>();
            foreach (var tagID in SelectedTags)
            {
                // get tag name
                var tag = taxMgr.GetTaxon(tagID);
                if (tag == null) continue;
                tags.Add(tag.Name);
            }

            // bind tag names
            TagsRepeater.DataSource = tags;
            TagsRepeater.DataBind();
        }

        /// <summary>
        /// Binds the selected tags to your categories control
        /// </summary>
        private void BindCategories()
        {
            // retrieve selected categories
            var tags = new List<string>();
            foreach (var tagID in SelectedCategories)
            {
                // get category name
                var tag = taxMgr.GetTaxon(tagID);
                if (tag == null) continue;
                tags.Add(tag.Name);
            }

            // bind category names
            CategoriesRepeater.DataSource = tags;
            CategoriesRepeater.DataBind();
        }

        #endregion

        #region Private members & constants
        public static readonly string layoutTemplatePath = "~/Custom/CustomDesignerExample/CustomWidget.ascx";
        #endregion
    }
}
